import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const ADMIN_PATHS = ["/admin", "/api/admin"];
const ADMIN_ONLY_API_PATHS = ["/api/admin/upload"];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const needsAdmin = ADMIN_PATHS.some((p) => pathname.startsWith(p));

  if (!needsAdmin || pathname === "/admin/login" || pathname === "/api/admin/login") {
    return NextResponse.next();
  }

  const role = request.cookies.get("veci_admin_session")?.value;
  const isAuthed = role === "admin" || role === "worker";
  if (isAuthed) {
    const needsAdminRole =
      ADMIN_ONLY_API_PATHS.some((p) => pathname.startsWith(p)) ||
      (pathname.startsWith("/api/admin/content") && request.method !== "GET");
    if (needsAdminRole && role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    return NextResponse.next();
  }

  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const loginUrl = new URL("/admin/login", request.url);
  loginUrl.searchParams.set("next", pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ["/admin/:path*", "/api/admin/:path*"],
};
